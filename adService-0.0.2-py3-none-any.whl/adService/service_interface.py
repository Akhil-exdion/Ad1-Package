from dataclasses import dataclass
from abc import ABC,abstractmethod
from typing import Any,List
from logging import Logger
from pydantic import BaseModel,FilePath


@dataclass
class PageInfo:
    words:list
    cords:list
    ocr_type:str
    width:int
    height:int
    image: Any   #np.ndarray but we want to avoid mentioning that as it adds numpy dependecy 
    
@dataclass
class DocInfo:
    file_path:str
    lob:str
    job_id:str
    doc_id:str
    es_hosts:list
    external_doc_id:str = ''

class SubElement(BaseModel):
    sub_element_generic_name:str
    sub_element_values:List[str]
    
class DataElement(BaseModel):
    data_element_name:str
    page_num:int
    file_path:FilePath
    doc_id:str
    sub_elements:List[SubElement]
    

class ExtractionOutput(BaseModel):
    page_data_elements:List[DataElement]


class ConnectorInterface(ABC):
    @abstractmethod
    def add_data(self,data:ExtractionOutput):
        pass
    @abstractmethod
    def delete_doc_data(self,doc_id):
        pass
    @abstractmethod
    def doc_id_exists(self,doc_id):
        pass
    @abstractmethod
    def add_to_db(self,data_list):
        """
        if already formatted data ,push directly to db
        """
        pass

class FilterInterface(ABC):
    @abstractmethod
    def filter_data(self,data:ExtractionOutput)->ExtractionOutput:
        pass

@dataclass
class DocReaderConfig:
    img_info:bool
    gray_scale:bool

class DocInterface(ABC):
    @abstractmethod
    def load_page(self,page_num:int)->PageInfo:
        pass
    @abstractmethod
    def page_count(self)->int:
        pass

class ExtractionEvent(ABC):
    @abstractmethod
    def on_init(self,logger:Logger):
        pass
    @abstractmethod
    def on_doc_data(self,doc_info:DocInfo,reader:DocInterface,output_connector:ConnectorInterface,output_filter:FilterInterface):
        pass