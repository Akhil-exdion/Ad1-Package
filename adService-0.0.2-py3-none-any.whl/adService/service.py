from logging import Logger
from .service_interface import ExtractionEvent,DocInterface,DocInfo,ConnectorInterface,FilterInterface,PageInfo,ExtractionOutput, SubElement, DataElement
import fitz
from typing import List
import sqlite3
import re
import requests

def ie_result_parser(data):
    
    
    # conn = sqlite3.connect('ExtractionAD-1.db')
    # cursor = conn.cursor()
    # insert_query = """
    # INSERT INTO DecData (
    #     DocID, PageNum, Label, Value, LabelClassID, 
    #     SplitValue1, SplitValue2, SplitValue3, SplitValue4, SplitValue5, SplitValue6, FromAuto
    # ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    # """ 
    data_list = []
    # # Loop through your data elements and insert into the database
    for data_element in data.page_data_elements:
        sub_element_value = data_element.sub_elements[0].sub_element_values[0] if data_element.sub_elements else None
        data_list.append([data_element.doc_id, data_element.page_num, data_element.data_element_name, sub_element_value,23])
    #     # Insert into the database with hardcoded and dynamic values
    #     cursor.execute(insert_query, (
    #         data_element.doc_id,         # DocID
    #         data_element.page_num,       # PageNum
    #         data_element.data_element_name,  # Label
    #         sub_element_value,           # Value
    #         23,                          # LabelClassID
    #         '',                          # SplitValue1
    #         '',                          # SplitValue2
    #         '',                          # SplitValue3
    #         '',                          # SplitValue4
    #         '',                          # SplitValue5
    #         '',                          # SplitValue6
    #         2                            # FromAuto
    #     ))
    
    # # Commit the transaction
    # conn.commit()
    # # Close the connection
    # conn.close()

    return data_list

class ConcreteDocReader(DocInterface):
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.doc = fitz.open(file_path)

    def load_page(self, page_num: int) -> PageInfo:
        page = self.doc.load_page(page_num)
        # full_text = page.get_text("text")
        words = page.get_text("words")
        words_list = [word[4] for word in words]
        cords = [word[:4] for word in words]
        width, height = page.rect.width, page.rect.height

        return PageInfo(words=words_list, cords=cords, ocr_type='pdf', width=width, height=height, image=None)

    def page_count(self) -> int:
        return self.doc.page_count        
        
class MyConnector(ConnectorInterface):
    def add_data(self, data: ExtractionOutput):
        if data.page_data_elements:
            data_list = ie_result_parser(data)
            print("Data added:")
            self.add_to_db(data_list)
    def delete_doc_data(self, doc_id):
        print(f"Document {doc_id} deleted from DB.")
    
    def doc_id_exists(self, doc_id):
        # Example: Always return False
        return False
    
    def add_to_db(self, data_list):
        print(f"Data list added to DB: {data_list}")

class SimpleFilter(FilterInterface):
    def filter_data(self, data: ExtractionOutput) -> ExtractionOutput:
        """
        A simple filter that could modify or filter data.
        For now, it returns the data as is.
        """
        # Here you could add filtering logic, e.g., filter out certain pages based on criteria
        return data
    
class MyExtractionEvent(ExtractionEvent):
    def __init__(self):
        self.logger = None

    def on_init(self, logger: Logger):
        """
        Initialize the extraction event with a logger.
        
        :param logger: A logger instance for logging events.
        """
        self.logger = logger
        self.logger.info("Initialization complete.")
    
    def on_doc_data(self, doc_info: DocInfo, reader: DocInterface, output_connector: ConnectorInterface, output_filter: FilterInterface):
        # # Keywords to search for
        keywords = ['coveredautosymbol',
                   'coveredautossymbol',
                   'coveredautoliabilitysymbol',
                   'coveredautosliabilitysymbol']
        
        # Create a KeywordSearcher instance
        searcher = KeywordSearcher(reader, keywords)
        
        # Find pages with the specified keywords
        pages_with_keywords = searcher.find_pages_with_keywords()
        
        sys_content = '''
        Your task involves a meticulous identification of specific COVERAGES, COVERED AUTO SYMBOLS and LIMIT OF INSURANCE from the given text.
        If there are nothing identified under the specified labels, please respond as "Not Found".'''
        
        API_KEY = "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"
        gpt_caller = GPTCaller(api_key=API_KEY)
        gpt_caller.set_prompt(sys_content)
        responses = gpt_caller.call_gpt(pages_with_keywords, reader)
        
        
        # Create the extraction output from the GPT output
        extraction_output = create_extraction_output(responses, doc_info.doc_id, doc_info.file_path)
        
        # Apply the output filter on the extraction data
        if output_filter:
            filtered_data = output_filter.filter_data(extraction_output)
        else:
            filtered_data = extraction_output
        
        # Pass filtered data to the output connector
        if output_connector:
            output_connector.add_data(filtered_data)
            
        self.logger.info(f"Pages containing keywords: {pages_with_keywords}")

        self.logger.info(f"Document {doc_info.doc_id} processed successfully.")

class GPTCaller:
    def __init__(self, api_key: str):
        """
        Initialize the GPTCaller with an API key for OpenAI.
        
        :param api_key: Your OpenAI API key.
        """
        self.api_key = api_key
        self.end_point = 'https://api.openai.com/v1/chat/completions'
        self.model = 'gpt-4o-mini'
        self.max_tokens = 1600

    def set_prompt(self, prompt: str):
        self.prompt = prompt

    def call_gpt(self, pages: List[int], doc_reader) -> List[str]:
        """
        Send page numbers to GPT and get responses.
        
        :param pages: A list of page numbers to be processed.
        :param doc_reader: An instance of DocInterface to read document pages.
        :return: A list of responses from GPT for each page.
        """
        responses = {}
        for page_num in pages:
            # Load page text
            page_info = doc_reader.load_page(page_num - 1)  # Adjusting for 0-based index

            text = ' '.join(page_info.words)

            data = {
                    'model': self.model,
                    'messages': [
                        {'role': 'system', 'content': self.prompt},{'role': 'user', 'content': text}
                    ],
                    "temperature": 1,
                    "max_tokens": self.max_tokens,
                    "seed": 123,
                    "top_p": 0.2,
                    "frequency_penalty": 0.2,
                    "presence_penalty": 0
                    }
            
            # Call GPT with the page text
            response = self._call_gpt_api(data)
            responses[page_num] = response
        
        return responses

    def _call_gpt_api(self, data: dict) -> str:
        try:
            API_KEY = self.api_key
            API_ENDPOINT = self.end_point
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {API_KEY}'
            }
            
            response = requests.post(API_ENDPOINT, headers=headers, json=data, timeout=120)
            response_json = response.json()
            return response_json['choices'][0]['message']['content']
        except Exception as e:
            error_msg = "Exception Raised in the ask_gpt3 Function "
            self.logger.error(f'{error_msg}   , Actual error:: {str(e)}')

def create_extraction_output(gpt_output: dict, doc_id: str, file_path: str) -> ExtractionOutput:
    page_data_elements = []
    for page_num, page_content in gpt_output.items():
        # Create SubElements (you can modify how this is parsed)
        sub_elements = [
            SubElement(sub_element_generic_name='value', sub_element_values=[page_content])
        ]
        
        # Create DataElement for each page
        data_element = DataElement(
            data_element_name='Coverage Territory',
            page_num = page_num,
            file_path = file_path,
            doc_id =  doc_id,
            class_id = 23,
            sub_elements=sub_elements
        )
        
        # Append to the list of page data elements
        page_data_elements.append(data_element)
    
    # Create ExtractionOutput object
    extraction_output = ExtractionOutput(page_data_elements=page_data_elements)

    return extraction_output

class KeywordSearcher:
    def __init__(self, doc_reader: DocInterface, keywords: List[str]):
        """
        Initialize the KeywordSearcher with a DocInterface object and a list of keywords.
        
        :param doc_reader: An instance of DocInterface for loading and reading the document.
        :param keywords: A list of keywords to search for in the document.
        """
        self.doc_reader = doc_reader
        self.keywords = keywords
        
    def alphabets_lower(self, text: str, lower_case: bool = True) -> str:
        text_without_spaces = re.sub(r'\s+', '', text)
        text_without_spaces_alphabt = re.sub(r'[^a-zA-Z]+', '', text_without_spaces)
        text_without_spaces_lower = text_without_spaces_alphabt.lower()
        text = text_without_spaces_lower if lower_case else text_without_spaces_alphabt
        return text
        
    def _contains_keywords(self, text: str) -> bool:
        """
        Check if any of the keywords are present in the given text.
        
        :param text: The text to search within.
        :return: True if any keyword is found, False otherwise.
        """
        processed_text = self.alphabets_lower(text)
        return any(keyword.lower() in processed_text for keyword in self.keywords)

    def find_pages_with_keywords(self) -> List[int]:
        """
        Find all pages in the document that contain any of the specified keywords.
        
        :return: A list of page numbers that contain at least one of the keywords.
        """
        pages_with_keywords = []

        total_pages = self.doc_reader.page_count()
        for page_num in range(total_pages):
            page_info = self.doc_reader.load_page(page_num)
            if self._contains_keywords(' '.join(page_info.words)):
                pages_with_keywords.append(page_num + 1)  # Page numbers are 1-based

        return pages_with_keywords


class AdExtraction:
    def __init__(self, logger: Logger):
        self.ad_service = MyExtractionEvent()
        self.logger = logger

    def process_document(self, doc_info: DocInfo, reader: DocInterface, output_connector: ConnectorInterface, output_filter: FilterInterface):
        """
        This method will initialize the service and process the document data.
        """
        # # Initialize the service with the logger
        self.ad_service.on_init(self.logger)
        
        # # Process document data
        self.ad_service.on_doc_data(doc_info, reader, output_connector, output_filter)

        self.logger.info(f'Finished processing document: {doc_info.doc_id}')